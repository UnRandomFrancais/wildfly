package fileattente.modele;

public class FileAttentePleineException extends Exception {

	private static final long serialVersionUID = 7974420835408306845L;

}
